Overview

This project is a Node.js and Express-based web server that exposes a set of HTTP APIs. It demonstrates server-side development concepts including routing, state management, automated testing, continuous integration, and containerized deployment.

The application is structured around two main features:
	A Random Number Generator API
	A Reverse Polish Notation (RPN) Calculator API	

It also includes automated test suites, GitLab CI configuration, and Docker support.


Random Number API

The server provides a simple stateful random number service.

It maintains a configurable maximum value and exposes endpoints that:
	Store and retrieve the current maximum value
	Generate a random integer between 0 (inclusive) and the configured maximum (exclusive)

This portion of the project demonstrates basic HTTP endpoint handling and persistent in-memory state within an Express application.


RPN Calculator API

The project includes an implementation of a Reverse Polish Notation (RPN) calculator, a stack-based calculator where operands precede operators.

The calculator API allows interaction with an internal stack through HTTP endpoints that support:
	Pushing values onto the stack
	Viewing and removing stack values
	Performing arithmetic operations such as addition

The RPN functionality showcases REST-style endpoint design, stack-based computation logic, and state manipulation through HTTP requests.


Testing

The repository contains automated tests located in the tests directory.

Two types of tests are included:
	Mocha and Chai unit tests, which validate the behavior of both the random number and RPN APIs
	Lightweight shell-based tests, designed for rapid validation of API responses

Together, these ensure correctness and reliability of the implemented endpoints.


Continuous Integration

The project includes a GitHub CI configuration that automatically runs the test suites when changes are pushed to the repository. This ensures that both the random number and RPN functionality remain fully verified in a continuous integration environment.


Docker Support

Containerization is supported through a Dockerfile and a Docker Compose configuration.

The Docker setup defines an image containing:
	The Node.js application
	All required dependencies

The application runs inside a container and exposes its HTTP server through a mapped port, allowing it to be accessed from the host machine.


Project Purpose

Overall, this project demonstrates:
	Express-based API development
	Stateful HTTP endpoint design
	Stack-based calculator implementation
	Automated testing with Mocha and Chai
	Continuous integration using GitLab CI
	Containerized deployment using Docker

It serves as a compact example of a full backend workflow from development through testing and deployment.